document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.querySelector('.map-section input[type="text"]');
  const categorySelect = document.querySelector('.map-section select');
  const cards = document.querySelectorAll('.gallery-section .card');
  const carousel = document.querySelector('.carousel');

  // Função para filtrar cards
  function filtrarCards() {
    const searchText = searchInput.value.toLowerCase();
    const categoria = categorySelect.value;

    cards.forEach(card => {
      const titulo = card.querySelector('h3').textContent.toLowerCase();
      const descricao = card.querySelector('p').textContent.toLowerCase();
      const cardCategoria = card.getAttribute('data-categoria');

      const textoCombina = titulo.includes(searchText) || descricao.includes(searchText);
      const categoriaCombina = categoria === 'todos' || categoria === cardCategoria;

      if (textoCombina && categoriaCombina) {
        card.style.display = 'block';
      } else {
        card.style.display = 'none';
      }
    });
  }

  searchInput.addEventListener('input', filtrarCards);
  categorySelect.addEventListener('change', filtrarCards);

  // Carrossel automático
  let scrollAmount = 0;
  const scrollStep = 260; // largura do card + gap aproximado
  const maxScroll = carousel.scrollWidth - carousel.clientWidth;

  function slideCarousel() {
    scrollAmount += scrollStep;
    if (scrollAmount > maxScroll) {
      scrollAmount = 0;
    }
    carousel.scrollTo({ left: scrollAmount, behavior: 'smooth' });
  }

  setInterval(slideCarousel, 3000);
});
